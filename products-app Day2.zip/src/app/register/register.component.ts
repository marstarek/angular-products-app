import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { UsernameValidator } from '../validators/username-validator';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  constructor(private fb: FormBuilder) {}
  get name() {
    return this.registerForm.get('name');
  }
  get userName() {
    return this.registerForm.get('userName');
  }
  get password() {
    return this.registerForm.get('password');
  }
  registerForm = this.fb.group({
    name: ['', Validators.required],
    email: [''],
    userName: ['', [Validators.required, UsernameValidator.cannotContainSpace]],
    password: [
      '',
      [
        Validators.required,
        Validators.minLength(8),
        Validators.pattern(
          '(?=.*[A-Za-z])(?=.*[0-9])(?=.*[$@$!#^~%*?&,.<>"\'\\;:{\\}\\[\\]\\|\\+\\-\\=\\_\\)\\(\\)\\`\\/\\\\\\]])[A-Za-z0-9d$@].{7,}'
        ),
      ],
    ],
    confPassword: [''],
    // userAddress: this.fb.group({
    //   address: [''],
    //   street: [''],
    //   country: [''],
    //   city: [''],
    // }),
  });
  title: string = 'Register';
  ngOnInit(): void {}
}
